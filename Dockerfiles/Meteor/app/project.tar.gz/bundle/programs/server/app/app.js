var require = meteorInstall({"imports":{"api":{"amqpdata.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// imports/api/amqpdata.js                                                           //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
Object.defineProperty(exports, '__esModule', {                                       //
  value: true                                                                        //
});                                                                                  //
                                                                                     //
var _meteorMongo = require('meteor/mongo');                                          //
                                                                                     //
var Amqpdata = new _meteorMongo.Mongo.Collection('amqp_collection');                 // 2
exports.Amqpdata = Amqpdata;                                                         //
///////////////////////////////////////////////////////////////////////////////////////

}],"kafkadata.js":["meteor/mongo",function(require,exports){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// imports/api/kafkadata.js                                                          //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
Object.defineProperty(exports, '__esModule', {                                       //
  value: true                                                                        //
});                                                                                  //
                                                                                     //
var _meteorMongo = require('meteor/mongo');                                          //
                                                                                     //
var Kafkadata = new _meteorMongo.Mongo.Collection('kafka_collection');               // 2
exports.Kafkadata = Kafkadata;                                                       //
///////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["meteor/meteor","../imports/api/kafkadata","../imports/api/amqpdata",function(require){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// server/main.js                                                                    //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
var _meteorMeteor = require('meteor/meteor');                                        //
                                                                                     //
var _importsApiKafkadata = require('../imports/api/kafkadata');                      //
                                                                                     //
var _importsApiAmqpdata = require('../imports/api/amqpdata');                        //
                                                                                     //
_meteorMeteor.Meteor.startup(function () {                                           // 4
    if (_importsApiKafkadata.Kafkadata.find().count() === 0) {                       // 5
        /*      const kafkadata = [{                                                 //
                  'name': 'Dubstep-Free Zone',                                       //
                  'description': 'Fast just got faster with Nexus S.'                //
              }, {                                                                   //
                  'name': 'All dubstep all the time',                                //
                  'description': 'Get it on!'                                        //
              }, {                                                                   //
                  'name': 'Savage lounging',                                         //
                  'description': 'Leisure suit required. And only fiercest manners.'
              }];                                                                    //
                kafkadata.forEach((party) => {                                       //
                  Kafkadata.insert(party)                                            //
              });*/                                                                  //
        // Kafkadata.distinct();                                                     //
    }                                                                                //
});                                                                                  //
///////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
