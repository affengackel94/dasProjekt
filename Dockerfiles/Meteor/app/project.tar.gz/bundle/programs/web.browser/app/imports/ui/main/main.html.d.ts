
        const template: string;
        export default template;
      